---
type: Education
kin: Skill
---
